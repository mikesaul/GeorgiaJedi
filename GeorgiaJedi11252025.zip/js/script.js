
/**
 * script.js — Complete updated version for autographs.html
 *
 * Features:
 * - Loads data from data/<page>.json
 * - Injects filter row, date and numeric range modals
 * - Clear All button visibility
 * - Formatters for bootstrap-table (date, currency, detail)
 * - Image link state encoding for imageview
 * - Export: CSV (tableExport), JSON (manual), Excel (SheetJS), PDF (jsPDF + AutoTable)
 * - Export modes: all | filtered | page | selected
 *
 * Added/Fixed:
 * - In-memory watermark cache (option A)
 * - Watermark applied to detail view and imageview only (Option C)
 * - Font loading for SF Distant Galaxy (encoded URL)
 * - Conditional crossOrigin on image loading (avoids taint/CORS issues)
 * - expand-row handler to ensure detail images get replaced right away
 *
 * Replace your existing /js/script.js with this file.
 */

(function () {
  'use strict';

  /* =========================
     Globals & Configuration
     ========================= */
  const DEFAULT_PAGE_SIZE = 5;
  let rawData = [];
  let currentFiltered = [];
  let exportMode = 'all'; // 'all' | 'filtered' | 'page' | 'selected'

  // Watermark cache (in-memory, page lifetime)
  // Map key: `${imageId}:thumb` or `${imageId}:full`
  // value: { status: 'pending'|'ready'|'error', promise: Promise, dataUrl: string|null }
  const WATERMARK_CACHE = new Map();

  // Font load cache/promise
  const FONT_NAME = 'SFDistantGalaxy';
  // encode spaces/unsafe chars to avoid FontFace load issues
  const FONT_URL_RAW = '/css/fonts/SF Distant Galaxy AltOutline.ttf';
  const FONT_URL = encodeURI(FONT_URL_RAW);
  let FONT_LOAD_PROMISE = null;

  /* =========================
     Utilities
     ========================= */
  function getItemType() {
    const p = window.location.pathname.split('/').pop();
    return (p || '').split('.').shift() || 'data';
  }

  function safeTrim(v) {
    return (v === undefined || v === null) ? '' : String(v).trim();
  }

  function isValidDate(d) {
    return d instanceof Date && !isNaN(d.getTime());
  }

  function parseDate(value) {
    if (value === undefined || value === null) return null;
    const s = String(value).trim();
    if (!s) return null;
    // try yyyy-mm-dd
    const iso = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (iso) return new Date(`${iso[1]}-${iso[2]}-${iso[3]}T00:00:00`);
    // try mm/dd/yyyy
    const parts = s.split('/');
    if (parts.length === 3) {
      const mm = parts[0].padStart(2, '0');
      const dd = parts[1].padStart(2, '0');
      const yyyy = parts[2];
      return new Date(`${yyyy}-${mm}-${dd}T00:00:00`);
    }
    const d = new Date(s);
    return isValidDate(d) ? d : null;
  }

  function toNumber(v) {
    if (v === undefined || v === null || String(v).trim() === '') return NaN;
    const n = parseFloat(String(v).replace(/[^0-9.-]+/g, ''));
    return isNaN(n) ? NaN : n;
  }

  function b64EncodeUnicode(str) {
    try {
      return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function (_, p1) {
        return String.fromCharCode('0x' + p1);
      }));
    } catch (e) {
      return '';
    }
  }

      // ---------------------------
    // Small reusable helpers
    // ---------------------------
  // Debounce helper used by filter wiring
  function debounce(fn, delay) {
    let timer = null;
    return function (...args) {
      const ctx = this;
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => {
        timer = null;
        fn.apply(ctx, args);
      }, delay);
    };
  }

  // CSV escape helper used by manual CSV builder
  function csvEscape(val) {
    if (val === null || val === undefined) return '';
    const s = String(val);
    if (/[",\n\r]/.test(s)) {
      return '"' + s.replace(/"/g, '""') + '"';
    }
    return s;
  }

  // Escape HTML to avoid injection and rendering issues
  function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  /* =========================
     Font Loading
     ========================= */

  // Loads the font once and caches the Promise. Resolves when font is available.
  function ensureFontLoaded() {
    if (FONT_LOAD_PROMISE) return FONT_LOAD_PROMISE;

    // If FontFace API is supported, try to load explicitly.
    if (window.FontFace) {
      try {
        const ff = new FontFace(FONT_NAME, `url("${FONT_URL}")`, { style: 'normal', weight: '400' });
        FONT_LOAD_PROMISE = ff.load().then(loadedFace => {
          try {
            document.fonts.add(loadedFace);
          } catch (e) {
            // ignore if adding fails
          }
          // also wait for the document fonts to be ready for the given family
          return document.fonts.load(`12px "${FONT_NAME}"`).then(() => true).catch(() => true);
        }).catch(err => {
          console.warn('FontFace load failed for', FONT_URL, err);
          // fallback: still resolve so rendering continues with fallback fonts
          return true;
        });
      } catch (e) {
        FONT_LOAD_PROMISE = Promise.resolve(true);
      }
    } else {
      // No FontFace API; try document.fonts.load or just resolve
      if (document.fonts && document.fonts.load) {
        FONT_LOAD_PROMISE = document.fonts.load(`12px "${FONT_NAME}"`).then(() => true).catch(() => true);
      } else {
        FONT_LOAD_PROMISE = Promise.resolve(true);
      }
    }
    return FONT_LOAD_PROMISE;
  }

  /* =========================
     Watermark rendering & cache (in-memory)
     ========================= */

  // Small helper to schedule work without blocking (uses requestIdleCallback when available)
  function scheduleWork(fn) {
    if (typeof requestIdleCallback === 'function') {
      requestIdleCallback(fn, { timeout: 500 });
    } else {
      // fallback - use setTimeout to yield to main thread
      setTimeout(fn, 16);
    }
  }

  // Helper to check if URL is same-origin (returns true if same origin)
  function isSameOrigin(url) {
    try {
      const u = new URL(url, window.location.href);
      return u.origin === window.location.origin;
    } catch (e) {
      return false;
    }
  }

  // render watermark onto a canvas and return dataURL
  // sizeHints: { width, height } optional; if not provided we'll use image natural size (for full)
  // This version loads the requested SF Distant Galaxy font (if available) and tiles the watermark diagonally.
  function renderWatermarkedDataUrl(imageUrl, watermarkText = 'GeorgiaJedi', sizeHints = null, rotation = -0.6, alpha = 0.5, fontSize = null) {
    return new Promise((resolve, reject) => {
      try {
        const img = new Image();

        // Only set crossOrigin if the image is cross-origin; avoid setting for same-origin to prevent issues
        if (!isSameOrigin(imageUrl)) {
          img.crossOrigin = 'anonymous';
        }

        img.onload = function () {
          // ensure font loaded first (so the drawing uses the correct glyphs)
          ensureFontLoaded().then(() => {
            scheduleWork(() => {
              try {
                const naturalW = img.naturalWidth || img.width || (sizeHints && sizeHints.width) || 800;
                const naturalH = img.naturalHeight || img.height || (sizeHints && sizeHints.height) || Math.round(naturalW * 0.75);

                // If a size hint is provided (e.g., thumbnail), use that; else constrain to max for performance
                let w = naturalW;
                let h = naturalH;
                if (sizeHints && sizeHints.width) w = sizeHints.width;
                if (sizeHints && sizeHints.height) h = sizeHints.height;

                // Cap extremely large images for performance
                const MAX_DIM = 1600;
                if (w > MAX_DIM) {
                  const ratio = MAX_DIM / w;
                  w = Math.round(w * ratio);
                  h = Math.round(h * ratio);
                }

                const canvas = document.createElement('canvas');
                canvas.width = w;
                canvas.height = h;
                const ctx = canvas.getContext('2d');

                // draw background image scaled to canvas
                ctx.drawImage(img, 0, 0, w, h);

                // watermark styling + repeated diagonal tiling
                ctx.save();
                ctx.translate(w / 2, h / 2);
                ctx.rotate(rotation);
                ctx.globalAlpha = alpha;

                // prepare font: prefer loaded SF Distant Galaxy, fallback to Arial
                const defaultFontPx = fontSize ? fontSize : Math.max(18, Math.round(w / 12));
                // use quoted font family
                ctx.font = `${defaultFontPx}px "${FONT_NAME}", Arial`;
                ctx.fillStyle = '#ffffff';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';

                // soft shadow for contrast
                ctx.shadowColor = 'rgba(0,0,0,0.6)';
                ctx.shadowBlur = 4;
                ctx.shadowOffsetX = 1;
                ctx.shadowOffsetY = 1;

                // tile the watermark across the rotated canvas center line
                // We'll draw repeated text along the x axis (after rotation), spaced by step.
                const step = Math.max(defaultFontPx * 4, 80);
                const span = Math.max(w, h) * 2; // length along x to cover after rotation
                for (let x = -span; x <= span; x += step) {
                  for (let y = -span; y <= span; y += step * 1.5) {
                    // lighter variation: stagger rows slightly
                    const dx = x + ( (y / step) % 2 ? step / 2 : 0 );
                    ctx.fillText(watermarkText, dx, y);
                  }
                }

                ctx.restore();

                // export as JPEG for smaller size (quality 0.85) — use JPEG for typical photos
                const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
                resolve(dataUrl);
              } catch (err) {
                reject(err);
              }
            });
          }).catch(() => {
            // font load failed but proceed (fallback font)
            scheduleWork(() => {
              try {
                const naturalW = img.naturalWidth || img.width || (sizeHints && sizeHints.width) || 800;
                const naturalH = img.naturalHeight || img.height || (sizeHints && sizeHints.height) || Math.round(naturalW * 0.75);

                let w = naturalW;
                let h = naturalH;
                if (sizeHints && sizeHints.width) w = sizeHints.width;
                if (sizeHints && sizeHints.height) h = sizeHints.height;
                const MAX_DIM = 1600;
                if (w > MAX_DIM) {
                  const ratio = MAX_DIM / w;
                  w = Math.round(w * ratio);
                  h = Math.round(h * ratio);
                }

                const canvas = document.createElement('canvas');
                canvas.width = w;
                canvas.height = h;
                const ctx = canvas.getContext('2d');

                ctx.drawImage(img, 0, 0, w, h);

                ctx.save();
                ctx.translate(w / 2, h / 2);
                ctx.rotate(rotation);
                ctx.globalAlpha = alpha;

                const defaultFontPx = fontSize ? fontSize : Math.max(18, Math.round(w / 12));
                ctx.font = `${defaultFontPx}px Arial`;
                ctx.fillStyle = '#ffffff';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.shadowColor = 'rgba(0,0,0,0.6)';
                ctx.shadowBlur = 4;
                ctx.shadowOffsetX = 1;
                ctx.shadowOffsetY = 1;

                const step = Math.max(defaultFontPx * 4, 80);
                const span = Math.max(w, h) * 2;
                for (let x = -span; x <= span; x += step) {
                  for (let y = -span; y <= span; y += step * 1.5) {
                    const dx = x + ( (y / step) % 2 ? step / 2 : 0 );
                    ctx.fillText(watermarkText, dx, y);
                  }
                }

                ctx.restore();
                const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
                resolve(dataUrl);
              } catch (err) {
                reject(err);
              }
            });
          });
        };
        img.onerror = function (err) {
          reject(new Error('Image failed to load: ' + imageUrl));
        };
        img.src = imageUrl;
      } catch (err) {
        reject(err);
      }
    });
  }

  // Public function to get watermarked data URL for a given image id and mode (thumb/full)
  // imageId - the base image name without extension (e.g., 'img123' if files are images/img123.jpg)
  // mode - 'thumb' or 'full'
  function getWatermarkedDataUrl(imageId, mode = 'thumb') {
    if (!imageId) return Promise.resolve(null);
    const key = `${imageId}:${mode}`;
    const existing = WATERMARK_CACHE.get(key);
    if (existing) {
      if (existing.status === 'ready') return Promise.resolve(existing.dataUrl);
      return existing.promise;
    }

    // Build the image URL to load (use thumbnails for 'thumb', full for 'full')
    const srcUrl = (mode === 'thumb') ? `images/thumbs/${imageId}_thumb.jpg` : `images/${imageId}.jpg`;

    // Prepare hints for thumb to keep thumbnails small
    const hints = (mode === 'thumb') ? { width: 128, height: 128 } : null;
    const fontSize = (mode === 'thumb') ? 14 : null;

    // create placeholder entry with a promise
    let resolveFn, rejectFn;
    const p = new Promise((resolve, reject) => {
      resolveFn = resolve;
      rejectFn = reject;
    });

    WATERMARK_CACHE.set(key, { status: 'pending', promise: p, dataUrl: null });

    // Kick off rendering asynchronously (non-blocking)
    // If the image fails, fall back to original URL
    scheduleWork(() => {
      renderWatermarkedDataUrl(srcUrl, 'GeorgiaJedi', hints, -0.6, 0.5, fontSize)
        .then(dataUrl => {
          WATERMARK_CACHE.set(key, { status: 'ready', promise: Promise.resolve(dataUrl), dataUrl });
          resolveFn(dataUrl);
        })
        .catch(err => {
          console.warn('Watermark render failed for', srcUrl, err);
          WATERMARK_CACHE.set(key, { status: 'error', promise: Promise.resolve(null), dataUrl: null });
          // resolve with null to indicate fallback to original
          resolveFn(null);
        });
    });

    return p;
  }

  // Expose for debugging (optional)
  window._WATERMARK_CACHE = WATERMARK_CACHE;
  window.getWatermarkedDataUrl = getWatermarkedDataUrl;

  /* =========================
     Formatters (exposed to window for bootstrap-table)
     ========================= */
  function dateFormatter(value) {
    const d = parseDate(value);
    return isValidDate(d) ? d.toISOString().split('T')[0] : '';
  }
  window.dateFormatter = dateFormatter;

  function dateSorter(a, b, order) {
    const A = parseDate(a), B = parseDate(b);
    const aOk = isValidDate(A), bOk = isValidDate(B);
    if (!aOk && !bOk) return 0;
    if (!aOk) return order === 'asc' ? 1 : -1;
    if (!bOk) return order === 'asc' ? -1 : 1;
    return A - B;
  }
  window.dateSorter = dateSorter;

  function currencyFormatter(value) {
    if (value === undefined || value === null || value === '') return '';
    const n = toNumber(value);
    if (isNaN(n)) return String(value);
    try {
      return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(n);
    } catch (e) {
      return '$' + n.toFixed(2);
    }
  }
  window.currencyFormatter = currencyFormatter;

  function originalCostFooter(data) {
    let total = 0;
    (data || []).forEach(r => total += toNumber(r.original_cost) || 0);
    return currencyFormatter(total);
  }
  window.originalCostFooter = originalCostFooter;

  function currentValueFooter(data) {
    let total = 0;
    (data || []).forEach(r => total += toNumber(r.current_value) || 0);
    return currencyFormatter(total);
  }
  window.currentValueFooter = currentValueFooter;

  function imageFooterFormatter(data) {
    let count = 0;
    (data || []).forEach(r => {
      if (r.image) {
        const fn = String(r.image).split('/').pop().toLowerCase();
        if (fn !== '100.png' && fn !== '100') count++;
      }
    });
    return `${count} images`;
  }
  window.imageFooterFormatter = imageFooterFormatter;

  function descFormatter(index, row) {
    const v = row.description || '';
    return v.length > 140 ? v.slice(0, 140) + '…' : v;
  }
  window.descFormatter = descFormatter;

  function rowStyle(row, index) {
    const classes = [];
    if (index % 2 === 0) classes.push('bg-ltgray');
    if (row.is_verified && (String(row.is_verified).toLowerCase() === 'yes' || row.is_verified === true)) classes.push('verified-row');
    return { classes: classes.join(' ') };
  }
  window.rowStyle = rowStyle;

  // detailFormatter optimized to use cached watermarked image when available.
  function detailFormatter(index, row) {
    // Cache HTML per row to avoid rebuilding repeatedly
    if (!row) return '';
    if (row.__detail_html) return row.__detail_html;

    // Detail image id used to update DOM after insertion
    const detailImgId = `detail-img-${escapeHtml(String(row.id))}`;
    // Use original full-size image as initial src so layout is stable; we'll replace it async
    const imgSrc = row.image ? `images/${row.image}.jpg` : 'images/100.png';
    const title = row['name/brand'] || row.title || '';
    const description = row.description || '';
    const serial = row.serialnumber || '';
    const franchise = row.franchise || '';
    const source = row.source || '';
    const orig = currencyFormatter(row.original_cost);
    const curr = currencyFormatter(row.current_value);

    // When possible, set the src to the cached dataurl synchronously (fast path)
    let initialSrc = imgSrc;
    const cached = row.image ? WATERMARK_CACHE.get(`${row.image}:full`) : null;
    if (cached && cached.status === 'ready' && cached.dataUrl) {
      initialSrc = cached.dataUrl;
    }

    // Build HTML — include data-original attribute so we can easily find it and update
    const html = `
      <div class="card" style="display:flex; border:1px solid #ddd; padding:10px;">
        <div style="flex:1; text-align:center;">
          <img id="${detailImgId}" data-original="${escapeHtml(row.image || '')}" src="${initialSrc}" style="max-width:100%; width:420px; border-radius:6px;">
        </div>
        <div style="flex:2; padding-left:20px;">
          <h4>${escapeHtml(title)}</h4>
          ${franchise ? `<p><b>Franchise:</b> ${escapeHtml(franchise)}</p>` : ''}
          ${description ? `<p>${escapeHtml(description)}</p>` : ''}
          ${source ? `<p><b>Source:</b> ${escapeHtml(source)}</p>` : ''}
          ${serial ? `<p><b>Serial#:</b> ${escapeHtml(serial)}</p>` : ''}
          ${orig ? `<p><b>Original Cost:</b> ${escapeHtml(orig)}</p>` : ''}
          ${curr ? `<p><b>Current Value:</b> ${escapeHtml(curr)}</p>` : ''}
        </div>
      </div>
    `;

    // store cached HTML on row object
    try { row.__detail_html = html; } catch (e) { /* ignore if row is immutable */ }

    // After the detail is inserted into DOM, update the image if cache wasn't ready
    if (row.image && (!cached || cached.status !== 'ready')) {
      row.__needs_detail_update = true;
    } else {
      row.__needs_detail_update = false;
    }

    return html;
  }

  window.detailFormatter = detailFormatter;

  /* =========================
     Image formatter (thumbnails: NOT watermarked per Option C)
     ========================= */
  function getTableState() {
    const opt = $('#catalog-table').bootstrapTable('getOptions') || {};
    const state = {
      pageNumber: opt.pageNumber || 1,
      pageSize: opt.pageSize || DEFAULT_PAGE_SIZE,
      sortName: opt.sortName || '',
      sortOrder: opt.sortOrder || '',
      searchText: opt.searchText || ''
    };

    const filters = {};
    $('.column-filter').each(function () {
      const k = $(this).data('column');
      const v = $(this).val();
      if (v !== undefined && v !== null && String(v) !== '') filters[k] = v;
    });

    const ac = $('#acquired-select').val();
    if (ac) filters.acquired = ac;
    if (ac === '__range__') {
      const rs = $('#acquired-range-start').val() || '';
      const re = $('#acquired-range-end').val() || '';
      if (rs || re) filters.acquired_range = `${rs}|${re}`;
    }

    const origSel = $('#original-select').val();
    if (origSel) filters.original_select = origSel;
    if (origSel === '__custom__') {
      const rs = $('#orig-range-min').val() || '';
      const re = $('#orig-range-max').val() || '';
      const rb = $('#orig-range-blank').is(':checked') ? '1' : '0';
      filters.original_range = `${rs}|${re}|${rb}`;
    }

    const currSel = $('#current-select').val();
    if (currSel) filters.current_select = currSel;
    if (currSel === '__custom__') {
      const rs = $('#curr-range-min').val() || '';
      const re = $('#curr-range-max').val() || '';
      const rb = $('#curr-range-blank').is(':checked') ? '1' : '0';
      filters.current_range = `${rs}|${re}|${rb}`;
    }

    state.filters = filters;
    return state;
  }
  window.getTableState = getTableState;

  // Thumbnail image formatter: thumbnails remain unwatermarked for speed
  function imageFormatter(value, row) {
    const sender = getItemType();
    let sParam = '';
    try { sParam = encodeURIComponent(b64EncodeUnicode(JSON.stringify(getTableState()))); } catch (e) {}
    const sQuery = sParam ? `&s=${sParam}` : '';
    const imgId = row.image || '';
    const thumbSrc = imgId ? `images/thumbs/${imgId}_thumb.jpg` : 'images/100.png';
    const thumbId = `thumb-${escapeHtml(String(row.id))}`;

    // initialSrc intentionally uses original thumbnail (no watermark)
    const initialSrc = thumbSrc;

    if (imgId) {
      return `<a href="imageview.html?image=${imgId}&sender=${sender}${sQuery}">
                <img id="${thumbId}" class="wj-thumb" height="128" width="128" src="${initialSrc}" alt="thumb">
              </a>
              <a href="update-item.html?id=${encodeURIComponent(row.id)}&itemType=${sender}" class="btn btn-sm btn-primary mt-2 admin-only">Edit</a>`;
    }
    return `<img height="128" src="images/100.png" alt="no image">
            <a href="update-item.html?id=${encodeURIComponent(row.id)}&itemType=${sender}" class="btn btn-sm btn-primary mt-2 admin-only">Edit</a>`;
  }
  window.imageFormatter = imageFormatter;

  /* =========================
     Filtering helpers
     ========================= */
  function customNumericFilter(value, filter) {
    if (!filter) return true;
    const m = String(filter).trim().match(/^(<=|>=|=|<|>)?\s*([\d,.]+)$/);
    if (!m) return true;
    const [, op = '=', numStr] = m;
    const fnum = parseFloat(numStr.replace(/,/g, ''));
    const valNum = parseFloat(String(value || '').replace(/[^0-9.-]+/g, ''));
    if (isNaN(valNum)) return false;
    switch (op) {
      case '<': return valNum < fnum;
      case '<=': return valNum <= fnum;
      case '=': return valNum === fnum;
      case '>=': return valNum >= fnum;
      case '>': return valNum > fnum;
      default: return valNum === fnum;
    }
  }

  function evaluateMinMaxPair(value, minStr, maxStr, blankOnly) {
    const valNum = parseFloat(String(value || '').replace(/[^0-9.-]+/g, ''));
    const isBlank = isNaN(valNum);
    if (blankOnly) return isBlank;
    if (isBlank) return false;

    if (minStr) {
      if (/^(<=|>=|=|<|>)/.test(minStr)) {
        if (!customNumericFilter(value, minStr)) return false;
      } else {
        const mn = parseFloat(minStr.replace(/[^0-9.-]+/g, ''));
        if (!isNaN(mn) && valNum < mn) return false;
      }
    }
    if (maxStr) {
      if (/^(<=|>=|=|<|>)/.test(maxStr)) {
        if (!customNumericFilter(value, maxStr)) return false;
      } else {
        const mx = parseFloat(maxStr.replace(/[^0-9.-]+/g, ''));
        if (!isNaN(mx) && valNum > mx) return false;
      }
    }
    return true;
  }

  function applyCustomFilters(data) {
    const acVal = $('#acquired-select').val() || '';
    const startDateStr = $('#acquired-range-start').val() || '';
    const endDateStr = $('#acquired-range-end').val() || '';
    const startDate = startDateStr ? parseDate(startDateStr) : null;
    const endDate = endDateStr ? parseDate(endDateStr) : null;

    const origSel = $('#original-select').val() || '';
    const currSel = $('#current-select').val() || '';

    const origCustomMin = $('#orig-range-min').val() || '';
    const origCustomMax = $('#orig-range-max').val() || '';
    const origCustomBlank = $('#orig-range-blank').is(':checked');

    const currCustomMin = $('#curr-range-min').val() || '';
    const currCustomMax = $('#curr-range-max').val() || '';
    const currCustomBlank = $('#curr-range-blank').is(':checked');

    const textFilters = {};
    $('.column-filter').each(function () {
      const k = $(this).data('column');
      const v = $(this).val();
      if (v !== undefined && v !== null && String(v).trim() !== '') textFilters[k] = String(v).trim().toLowerCase();
    });

    const filtered = (data || []).filter(row => {
      // acquired date rules
      if (acVal === '__blank__') {
        if (isValidDate(parseDate(row.acquired))) return false;
      } else if (acVal && acVal.startsWith('year:')) {
        const y = parseInt(acVal.split(':')[1], 10);
        const d = parseDate(row.acquired);
        if (!isValidDate(d) || d.getFullYear() !== y) return false;
      } else if (acVal === '__range__') {
        if (startDate || endDate) {
          const d = parseDate(row.acquired);
          if (!isValidDate(d)) return false;
          if (startDate && d < startDate) return false;
          if (endDate && d > endDate) return false;
        }
      }

      // original cost
      if (origSel === '__blank__') {
        if (!isNaN(toNumber(row.original_cost))) return false;
      } else if (/^preset:/.test(origSel)) {
        const parts = origSel.split(':');
        if (parts[1] === 'under') {
          const mx = parts[2] ? parseFloat(parts[2]) : NaN;
          const v = toNumber(row.original_cost);
          if (isNaN(v) || v > mx) return false;
        } else if (parts[1] === 'over') {
          const mn = parts[2] ? parseFloat(parts[2]) : NaN;
          const v = toNumber(row.original_cost);
          if (isNaN(v) || v <= mn) return false;
        }
      } else if (origSel === '__custom__') {
        if (!evaluateMinMaxPair(row.original_cost, origCustomMin, origCustomMax, origCustomBlank)) return false;
      }

      // current value
      if (currSel === '__blank__') {
        if (!isNaN(toNumber(row.current_value))) return false;
      } else if (/^preset:/.test(currSel)) {
        const parts = currSel.split(':');
        if (parts[1] === 'under') {
          const mx = parts[2] ? parseFloat(parts[2]) : NaN;
          const v = toNumber(row.current_value);
          if (isNaN(v) || v > mx) return false;
        } else if (parts[1] === 'over') {
          const mn = parts[2] ? parseFloat(parts[2]) : NaN;
          const v = toNumber(row.current_value);
          if (isNaN(v) || v <= mn) return false;
        }
      } else if (currSel === '__custom__') {
        if (!evaluateMinMaxPair(row.current_value, currCustomMin, currCustomMax, currCustomBlank)) return false;
      }

      for (const [k, v] of Object.entries(textFilters)) {
        if (k === 'original_cost' || k === 'current_value') {
          if (!customNumericFilter(row[k], v)) return false;
        } else {
          const cell = String(row[k] || '').toLowerCase();
          if (!cell.includes(v)) return false;
        }
      }

      return true;
    });

    currentFiltered = filtered;
    return filtered;
  }
  window.applyCustomFilters = applyCustomFilters;

  /* =========================
     UI: build filter row and modals
     ========================= */
  function buildNumericSelectHtml(id) {
    let html = `<select id="${id}-select" class="form-control form-control-sm numeric-select" data-column="${id}">`;
    html += `<option value="">All</option>`;
    html += `<option value="__blank__">Blank only</option>`;
    html += `<option value="preset:under:25">Under $25</option>`;
    html += `<option value="preset:under:100">Under $100</option>`;
    html += `<option value="preset:over:500">Over $500</option>`;
    html += `<option value="preset:over:1000">Over $1k</option>`;
    html += `<option value="__custom__">Custom Range…</option>`;
    html += `</select>`;
    return html;
  }

  function populateAcquiredOptions() {
    const years = [...new Set((rawData || []).map(r => parseDate(r.acquired)).filter(Boolean).map(d => d.getFullYear()))].sort((a, b) => b - a);
    const $sel = $('#acquired-select');
    if (!$sel.length) return;
    let html = '<option value="">All</option>';
    html += '<option value="__blank__">Blank only</option>';
    html += '<option value="__range__">Custom Range…</option>';
    years.forEach(y => html += `<option value="year:${y}">${y}</option>`);
    $sel.html(html);
  }

  function injectFilterRow() {
    const $thead = $('#catalog-table thead');
    if (!$thead.length) return;
    if ($thead.find('tr.filter-row').length) return;

    const $filterRow = $('<tr class="filter-row"></tr>');
    $thead.find('th').each(function () {
      const field = $(this).data('field');
      const $cell = $('<td></td>');
      if (field === 'state' || $(this).attr('data-checkbox')) {
        $cell.append(`<button id="clear-filters" class="btn btn-sm btn-warning" style="width:100px; min-width:100px; max-width:100px; font-size:0.8em; display:none; margin:4px auto 2px auto;">Clear All</button>`);
      } else if (field === 'acquired') {
        $cell.append(`<select id="acquired-select" class="form-control form-control-sm" data-column="acquired"></select>`);
      } else if (field === 'name/brand') {
        $cell.append('<input type="text" class="column-filter form-control form-control-sm" data-column="name/brand" placeholder="Search title">');
      } else if (['franchise', 'size/model#', 'source'].includes(field)) {
        $cell.append(`<select class="column-filter form-control form-control-sm" data-column="${field}"><option value="">All</option></select>`);
      } else if (field === 'description') {
        $cell.append('<input type="text" class="column-filter form-control form-control-sm" data-column="description" placeholder="Search description">');
      } else if (field === 'original_cost') {
        $cell.append(buildNumericSelectHtml('original'));
      } else if (field === 'current_value') {
        $cell.append(buildNumericSelectHtml('current'));
      } else if (field === 'is_verified') {
        $cell.append('<input type="text" class="column-filter form-control form-control-sm" data-column="is_verified" placeholder="yes">');
      } else {
        $cell.append('');
      }
      $filterRow.append($cell);
    });

    $thead.append($filterRow);

    populateAcquiredOptions();
    ['franchise', 'size/model#', 'source'].forEach(col => {
      const unique = [...new Set((rawData || []).map(i => i[col]).filter(Boolean))].sort((a, b) => String(a).localeCompare(String(b), undefined, { sensitivity: 'base' }));
      const $sel = $(`select.column-filter[data-column="${col}"]`);
      if ($sel.length) {
        $sel.empty().append('<option value="">All</option>');
        unique.forEach(v => $sel.append(`<option value="${v}">${v}</option>`));
      }
    });
  }

  function showDateRangeModal() {
    const $m = $('#date-range-modal');
    if (!$m.length) return;
    $m.show();
    $m.find('.modal-box').css({ transform: 'translateY(0)', opacity: 1 });
  }
  function hideDateRangeModal() {
    const $m = $('#date-range-modal');
    if (!$m.length) return;
    $m.find('.modal-box').css({ transform: 'translateY(-12px)', opacity: 0 });
    setTimeout(() => $m.hide(), 220);
  }

  function showNumericModal(which) {
    const id = which === 'original' ? '#numeric-range-modal-original' : '#numeric-range-modal-current';
    const $m = $(id);
    if (!$m.length) return;
    $m.show();
    $m.find('.modal-box').css({ transform: 'translateY(0)', opacity: 1 });
  }
  function hideNumericModal(which) {
    const id = which === 'original' ? '#numeric-range-modal-original' : '#numeric-range-modal-current';
    const $m = $(id);
    if (!$m.length) return;
    $m.find('.modal-box').css({ transform: 'translateY(-12px)', opacity: 0 });
    setTimeout(() => $m.hide(), 220);
  }

  function anyFilterActive() {
    const hasColumnFilters = $('.column-filter').filter(function () {
      return $(this).val() && String($(this).val()).trim() !== '';
    }).length > 0;
    const ac = $('#acquired-select').val();
    const hasAc = ac && ac !== '';
    const origSel = $('#original-select').val();
    const currSel = $('#current-select').val();
    const hasNumericSelect = (origSel && origSel !== '') || (currSel && currSel !== '');
    const hasNumericModalValues = ($('#orig-range-min').val() && $('#orig-range-min').val().trim() !== '') ||
                                  ($('#orig-range-max').val() && $('#orig-range-max').val().trim() !== '') ||
                                  ($('#curr-range-min').val() && $('#curr-range-min').val().trim() !== '') ||
                                  ($('#curr-range-max').val() && $('#curr-range-max').val().trim() !== '') ||
                                  $('#orig-range-blank').is(':checked') || $('#curr-range-blank').is(':checked');
    return hasColumnFilters || hasAc || hasNumericSelect || hasNumericModalValues;
  }

  function updateClearButtonVisibility() {
    $('#clear-filters').toggle(anyFilterActive());
  }

  /* =========================
     Exports: native excel/pdf + csv/json via tableExport
     ========================= */


     // Native Excel using SheetJS (dynamic import)
  function exportToExcel(data, fileName) {
    if (typeof XLSX === 'undefined') {
      alert("SheetJS (XLSX) library not loaded.");
      return;
    }
    if (!data || !data.length) {
      alert("No data to export.");
      return;
    }

    try {
      // Clone data so we don't modify original
      const cleanData = data.map(row => {
        const newRow = { ...row };
        ["OriginalCost", "CurrentValue"].forEach(key => {
          if (newRow[key] != null) {
            // Remove all non-digit/non-dot characters (like $ or GBP)
            const num = parseFloat(newRow[key].toString().replace(/[^0-9.-]+/g,""));
            newRow[key] = isNaN(num) ? 0 : num;
          }
        });
        return newRow;
      });

      const ws = XLSX.utils.json_to_sheet(cleanData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Export");

      // Find column indices for OriginalCost and CurrentValue
      const headers = Object.keys(cleanData[0]);
      const origIdx = headers.indexOf("OriginalCost");
      const currIdx = headers.indexOf("CurrentValue");

      if (origIdx !== -1 || currIdx !== -1) {
        const totalRowNum = cleanData.length + 2; // +1 for header, +1 for 1-based indexing
        const totalLabelCell = XLSX.utils.encode_cell({ r: totalRowNum - 1, c: headers.length - 3 });
        ws[totalLabelCell] = { t: "s", v: "Total:" };

        ["OriginalCost", "CurrentValue"].forEach((key, i) => {
          const idx = key === "OriginalCost" ? origIdx : currIdx;
          if (idx !== -1) {
            const col = XLSX.utils.encode_col(idx);
            const formula = `SUM(${col}2:${col}${cleanData.length + 1})`;
            const cellRef = XLSX.utils.encode_cell({ r: totalRowNum - 1, c: idx });
            ws[cellRef] = { t: "n", f: formula, z: "$#,##0.00" }; // currency format
          }
        });

        ws["!ref"] = XLSX.utils.encode_range({
          s: { r: 0, c: 0 },
          e: { r: totalRowNum - 1, c: headers.length - 1 }
        });

        // Optional: set currency format for all rows
        cleanData.forEach((row, rowIndex) => {
          ["OriginalCost", "CurrentValue"].forEach(key => {
            const idx = headers.indexOf(key);
            if (idx !== -1) {
              const cellRef = XLSX.utils.encode_cell({ r: rowIndex + 1, c: idx });
              if (ws[cellRef]) ws[cellRef].z = "$#,##0.00";
            }
          });
        });
      }

      XLSX.writeFile(wb, fileName + ".xlsx");
    } catch (err) {
      console.error("Excel export failed:", err);
      alert("Excel export failed.");
    }
  }


  // Native PDF using jsPDF + AutoTable
  function exportToPDF(data, fileName) {
    const jspdfPresent = (window.jspdf && window.jspdf.jsPDF) || window.jsPDF;
    if (!jspdfPresent) {
      alert('jsPDF + AutoTable not loaded; cannot export PDF.');
      return;
    }
    if (!data || !data.length) {
      alert('No data to export.');
      return;
    }

    const { jsPDF } = window.jspdf || { jsPDF: window.jsPDF };
    const doc = new jsPDF({ orientation: 'l', unit: 'pt', format: 'a4' });

    // Build headers and body
    const headers = Object.keys(data[0] || {});
    const body = data.map(row => headers.map(h => row[h] ?? ''));

    // optional title
    doc.setFontSize(12);
    doc.text(fileName, 40, 30);

    doc.autoTable({
      head: [headers],
      body: body,
      startY: 50,
      styles: { fontSize: 8, cellPadding: 2 },
      headStyles: { fillColor: [41, 128, 185] }
    });

    doc.save(fileName + '.pdf');
  }

  // performExport uses native Excel & PDF handlers, tableExport for CSV
  function performExport(format) {
    const $table = $('#catalog-table');
    let dataToExport = [];

    if (exportMode === 'selected') {
      dataToExport = $table.bootstrapTable('getSelections') || [];
    } else if (exportMode === 'page') {
      try {
        dataToExport = $table.bootstrapTable('getData', { useCurrentPage: true }) || $table.bootstrapTable('getData');
      } catch (err) {
        const opts = $table.bootstrapTable('getOptions') || {};
        const pageNumber = opts.pageNumber || 1;
        const pageSize = opts.pageSize || DEFAULT_PAGE_SIZE;
        const all = $table.bootstrapTable('getData') || [];
        dataToExport = all.slice((pageNumber - 1) * pageSize, pageNumber * pageSize);
      }
    } else if (exportMode === 'filtered') {
      dataToExport = applyCustomFilters(rawData);
    } else { // 'all'
      dataToExport = rawData.slice();
    }

    if (!dataToExport || dataToExport.length === 0) {
      alert('No rows available to export.');
      return;
    }

    // map to a clean object list for export (consistent columns)
    // NOTE: include a watermarked image data URL if already cached (fast path). If not cached yet, include the original path.
    const mapped = dataToExport.map(r => {
      const baseImage = r.image ? r.image : '';
      const cachedThumb = baseImage ? WATERMARK_CACHE.get(`${baseImage}:thumb`) : null;
      const cachedFull = baseImage ? WATERMARK_CACHE.get(`${baseImage}:full`) : null;
      const imageForExport = (cachedFull && cachedFull.status === 'ready' && cachedFull.dataUrl) ? cachedFull.dataUrl :
                              (cachedThumb && cachedThumb.status === 'ready' && cachedThumb.dataUrl) ? cachedThumb.dataUrl :
                              (baseImage ? `images/${baseImage}.jpg` : '');

      return {
        ID: r.id,
        Acquired: r.acquired,
        Title: r['name/brand'] || r.title || '',
        Franchise: r.franchise || '',
        Description: r.description || '',
        Source: r.source || '',
        OriginalCost: r.original_cost || '',
        CurrentValue: r.current_value || '',
        IsVerified: r.is_verified || '',
        WatermarkedImage: imageForExport
      };
    });

    const filename = ($('#export-filename').val().trim() || getItemType() + '-export');

    if (format === 'json') {
      const blob = new Blob([JSON.stringify(mapped, null, 2)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = filename + '.json';
      a.click();
      return;
    }

    if (format === 'csv') {
      const cols = Object.keys(mapped[0] || {});
      // build header
      const rowsCsv = [];
      rowsCsv.push(cols.map(c => csvEscape(c)).join(','));
      // build rows
      mapped.forEach(r => {
        const line = cols.map(c => csvEscape(r[c] ?? '')).join(',');
        rowsCsv.push(line);
      });
      const csv = rowsCsv.join('\r\n');
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = filename + '.csv';
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        document.body.removeChild(a);
        URL.revokeObjectURL(a.href);
      }, 150);
      return;
    }

    if (format === 'excel') {
      exportToExcel(mapped, filename);
      return;
    }

    if (format === 'pdf') {
      exportToPDF(mapped, filename);
      return;
    }

    alert('Unsupported export format: ' + format);
  }

  /* =========================
     Initialization & Event bindings after JSON load
     ========================= */
  $(function () {
    const type = getItemType();
    const path = `data/${type}.json`;

    // Ensure jsPDF global alias if loaded via UMD
    if (window.jspdf && !window.jsPDF) {
      try { window.jsPDF = window.jspdf.jsPDF; } catch (e) {}
    }
    // Also provide fallback alias if jsPDF already present as window.jsPDF
    if (window.jsPDF && !window.jspdf) {
      try { window.jspdf = { jsPDF: window.jsPDF }; } catch (e) {}
    }

    $.getJSON(path)
      .done(function (json) {
        rawData = json || [];
        initTableAndBindings();
      })
      .fail(function (jqxhr, status, err) {
        console.error('Failed to load', path, status, err);
        rawData = [];
        initTableAndBindings();
      });

    function initTableAndBindings() {
      $('#catalog-table').bootstrapTable('destroy').bootstrapTable({
        data: rawData,
        pagination: true,
        pageSize: DEFAULT_PAGE_SIZE,
        pageList: [5, 10, 25, 50, 100],
        toolbar: '#toolbar',
        clickToSelect: false,
        idField: 'id',
        detailView: true,
        detailViewByClick: true,
        detailFormatter: detailFormatter,
        rowStyle: rowStyle,
        showFooter: true
      });

      injectFilterRow();

      // initial hide modals
      $('#date-range-modal').hide();
      $('#numeric-range-modal-original').hide();
      $('#numeric-range-modal-current').hide();

      // Bind change handlers for dynamic selects
      $(document).on('change', '#acquired-select', function () {
        const v = $(this).val() || '';
        if (v === '__range__') { showDateRangeModal(); updateClearButtonVisibility(); return; }
        hideDateRangeModal();
        const f = applyCustomFilters(rawData);
        $('#catalog-table').bootstrapTable('load', f);
        autoSwitchExportModeIfFilteredActive();
        updateClearButtonVisibility();
      });

      $(document).on('change', '.numeric-select', function () {
        const id = $(this).attr('id') || '';
        const who = id.split('-')[0];
        const val = $(this).val() || '';
        if (val === '__custom__') {
          if (who === 'original') { $('#orig-range-min').val($('#orig-range-min').val() || ''); $('#orig-range-max').val($('#orig-range-max').val() || ''); $('#orig-range-blank').prop('checked', $('#orig-range-blank').is(':checked')); showNumericModal('original'); }
          else { $('#curr-range-min').val($('#curr-range-min').val() || ''); $('#curr-range-max').val($('#curr-range-max').val() || ''); $('#curr-range-blank').prop('checked', $('#curr-range-blank').is(':checked')); showNumericModal('current'); }
          updateClearButtonVisibility(); return;
        }
        const f = applyCustomFilters(rawData);
        $('#catalog-table').bootstrapTable('load', f);
        autoSwitchExportModeIfFilteredActive();
        updateClearButtonVisibility();
      });

// PATCH part 3 20251121

      // centralized filter application (debounced)
      function applyFiltersImmediate() {
        const f = applyCustomFilters(rawData);
        $('#catalog-table').bootstrapTable('load', f);
        autoSwitchExportModeIfFilteredActive();
        updateClearButtonVisibility();
      }
      const applyFiltersDebounced = debounce(applyFiltersImmediate, 200);

      // wire inputs to centralized debounced function
      $(document).on('input change', '.column-filter', function () {
        applyFiltersDebounced();
      });


      // Date modal apply/cancel
      $(document).on('click', '#date-range-apply', function (e) {
        e.preventDefault();
        hideDateRangeModal();
        const f = applyCustomFilters(rawData);
        $('#catalog-table').bootstrapTable('load', f);
        autoSwitchExportModeIfFilteredActive();
        updateClearButtonVisibility();
      });
      $(document).on('click', '#date-range-cancel', function (e) {
        e.preventDefault();
        hideDateRangeModal();
        updateClearButtonVisibility();
      });

      // Numeric modals
      $(document).on('click', '#orig-range-apply', function (e) {
        e.preventDefault(); hideNumericModal('original'); const f = applyCustomFilters(rawData); $('#catalog-table').bootstrapTable('load', f); autoSwitchExportModeIfFilteredActive(); updateClearButtonVisibility(); 
      });
      $(document).on('click', '#orig-range-cancel', function (e) {
        e.preventDefault(); hideNumericModal('original'); updateClearButtonVisibility(); 
      });
      $(document).on('click', '#curr-range-apply', function (e) {
        e.preventDefault(); hideNumericModal('current'); const f = applyCustomFilters(rawData); $('#catalog-table').bootstrapTable('load', f); autoSwitchExportModeIfFilteredActive(); updateClearButtonVisibility(); 
      });
      $(document).on('click', '#curr-range-cancel', function (e) {
        e.preventDefault(); hideNumericModal('current'); updateClearButtonVisibility(); 
      });

      // Clear all
      $(document).on('click', '#clear-filters', function (e) {
        e.preventDefault();
        $('.column-filter').val('');
        $('#acquired-select').val('');
        $('.numeric-select').val('');
        $('#acquired-range-start, #acquired-range-end').val('');
        $('#orig-range-min, #orig-range-max').val('');
        $('#curr-range-min, #curr-range-max').val('');
        $('#orig-range-blank, #curr-range-blank').prop('checked', false);
        hideDateRangeModal(); hideNumericModal('original'); hideNumericModal('current');
        $('#catalog-table').bootstrapTable('load', rawData);

        // Reset export mode to All when clearing filters
        exportMode = "all";
        $('#exportModeBtn').text("Export Mode: All Rows");
        $('.export-mode').removeClass('active');
        $('.export-mode[data-mode="all"]').addClass('active');

        updateClearButtonVisibility();
      });

      // AUTO-SWITCH EXPORT MODE TO FILTERED WHEN ANY FILTER IS ACTIVE
      function autoSwitchExportModeIfFilteredActive() {
        // Only switch if user hasn't manually chosen a different mode
        if (exportMode === "all") {
            exportMode = "filtered";

            // Update button label
            $('#exportModeBtn').text("Export Mode: Filtered Rows");

            // Update dropdown active state
            $('.export-mode').removeClass('active');
            $('.export-mode[data-mode="filtered"]').addClass('active');
        }
      }

      // Export mode selection
      $(document).on('click', '.export-mode', function (e) {
        e.preventDefault();

        const mode = $(this).data('mode');
        if (!mode) return;

        // Update internal state
        exportMode = mode;

        // Update active highlight
        $('.export-mode').removeClass('active');
        $(this).addClass('active');

        // Update button label text
        const labelMap = {
            all: "All Rows",
            filtered: "Filtered Rows",
            page: "Visible Data",
            selected: "Selected Rows"
        };

        $('#exportModeBtn').text("Export Mode: " + labelMap[mode]);
      });

      // Export buttons
      $(document).on('click', '#export-csv', function () { performExport('csv'); });
      $(document).on('click', '#export-excel', function () { performExport('excel'); });
      $(document).on('click', '#export-json', function () { performExport('json'); });
      $(document).on('click', '#export-pdf', function () { performExport('pdf'); });

      // Sync label when filters change
      $(document).on('change input', '.column-filter, #acquired-select, .numeric-select, #orig-range-min, #orig-range-max, #curr-range-min, #curr-range-max, #orig-range-blank, #curr-range-blank', function () {
        setTimeout(updateExportModeLabel, 10);
      });

      // post-body callback: ensure thumbnails/details swap to cached watermarked images asynchronously
      $('#catalog-table').on('post-body.bs.table', function () {
        // 1) Update all thumbnail imgs we injected with id thumb-<rowid>
        // (thumbnails are intentionally left un-watermarked, but if you prefer we can swap to watermarked thumbs here)
        $('#catalog-table img.wj-thumb').each(function () {
          const imgEl = this;
          const $img = $(imgEl);
          const idAttr = $img.attr('id') || '';
          // extract row id from idAttr 'thumb-<rowid>', find matching row to get image name
          const match = idAttr.match(/^thumb-(.+)$/);
          if (!match) return;
          const rowId = match[1];
          // find the row in rawData
          const row = (rawData || []).find(r => String(r.id) === String(rowId));
          if (!row || !row.image) return;
          // intentionally do not call getWatermarkedDataUrl for thumbnails by default (Option C)
          // if you later want thumbnails watermarked, call getWatermarkedDataUrl(row.image,'thumb') and update src here
        });

        // 2) Update detail images for rows that flagged __needs_detail_update
        // detail view container is created on demand; update any detail image element if present
        $('.bootstrap-table .detail-view .card img[id^="detail-img-"]').each(function () {
          const el = this;
          const idAttr = $(el).attr('id') || '';
          const match = idAttr.match(/^detail-img-(.+)$/);
          if (!match) return;
          const rowId = match[1];
          const row = (rawData || []).find(r => String(r.id) === String(rowId));
          if (!row || !row.image) return;
          const key = `${row.image}:full`;
          const cacheEntry = WATERMARK_CACHE.get(key);
          if (cacheEntry && cacheEntry.status === 'ready' && cacheEntry.dataUrl) {
            if (el.src !== cacheEntry.dataUrl) el.src = cacheEntry.dataUrl;
            return;
          }
          // schedule watermark generation and update when ready (non-blocking)
          getWatermarkedDataUrl(row.image, 'full').then(dataUrl => {
            if (dataUrl) {
              try { el.src = dataUrl; } catch (e) {}
            }
          }).catch(() => { /* ignore */ });
        });

      });

      // NEW: when a row is expanded, update its detail image immediately
      $('#catalog-table').on('expand-row.bs.table', function (e, index, row, $detail) {
        try {
          if (!row || !row.image) return;
          // find the image element inside the $detail
          // $detail is a jQuery object containing the detail content
          const $img = $detail.find(`img#detail-img-${escapeHtml(String(row.id))}`);
          if ($img && $img.length) {
            const el = $img.get(0);
            const key = `${row.image}:full`;
            const cacheEntry = WATERMARK_CACHE.get(key);
            if (cacheEntry && cacheEntry.status === 'ready' && cacheEntry.dataUrl) {
              if (el.src !== cacheEntry.dataUrl) el.src = cacheEntry.dataUrl;
            } else {
              // generate and update
              getWatermarkedDataUrl(row.image, 'full').then(dataUrl => {
                if (dataUrl) {
                  try { el.src = dataUrl; } catch (e) {}
                }
              }).catch(() => {});
            }
          } else {
            // As fallback, try to find any image inside detail and update it
            $detail.find('img').each(function () {
              const el = this;
              // if the image's src contains the image id, or has data-original, update it
              const dataOriginal = $(el).attr('data-original') || '';
              if (String(dataOriginal) === String(row.image) || (el.src && el.src.indexOf(row.image) !== -1)) {
                getWatermarkedDataUrl(row.image, 'full').then(dataUrl => {
                  if (dataUrl) {
                    try { el.src = dataUrl; } catch (e) {}
                  }
                }).catch(() => {});
              }
            });
          }
        } catch (err) {
          // non-fatal
          console.warn('expand-row watermark update failed', err);
        }

      });

      // initial UI state
      updateClearButtonVisibility();
    }
  });

  window.performExport = performExport;

  /* =========================
     imageview.html integration
     - If the page has ?image=<id> we will replace the main image(s) with the cached watermarked full image
     - Also updates any img elements with data-imageid attributes
     ========================= */
  (function wireImageviewIntegration() {
    function getQueryParam(name) {
      try {
        const qs = new URLSearchParams(window.location.search);
        return qs.get(name);
      } catch (e) {
        return null;
      }
    }

    function applyWatermarkToImageElements(imageId) {
      if (!imageId) return;
      // try to find a primary image element by id common patterns
      const primarySelectors = ['#imageview-img', '#main-image', '.imageview-main img', 'img.viewer', 'img#viewer'];
      primarySelectors.forEach(sel => {
        const el = document.querySelector(sel);
        if (el) {
          // fast-path if cache ready
          const cacheEntry = WATERMARK_CACHE.get(`${imageId}:full`);
          if (cacheEntry && cacheEntry.status === 'ready' && cacheEntry.dataUrl) {
            if (el.src !== cacheEntry.dataUrl) el.src = cacheEntry.dataUrl;
          } else {
            // schedule generation and update when ready
            getWatermarkedDataUrl(imageId, 'full').then(dataUrl => {
              if (dataUrl && el) {
                try { el.src = dataUrl; } catch (e) {}
              }
            }).catch(() => {});
          }
        }
      });

      // also update any img elements that have data-imageid attribute matching the id
      document.querySelectorAll(`img[data-imageid="${imageId}"]`).forEach(el => {
        const cacheEntry = WATERMARK_CACHE.get(`${imageId}:full`);
        if (cacheEntry && cacheEntry.status === 'ready' && cacheEntry.dataUrl) {
          if (el.src !== cacheEntry.dataUrl) el.src = cacheEntry.dataUrl;
        } else {
          getWatermarkedDataUrl(imageId, 'full').then(dataUrl => {
            if (dataUrl && el) {
              try { el.src = dataUrl; } catch (e) {}
            }
          }).catch(() => {});
        }
      });

      // as a last measure, replace any <img> whose src contains the imageId string
      document.querySelectorAll('img').forEach(el => {
        try {
          if (!el.src) return;
          if (el.src.indexOf(imageId) !== -1) {
            const cacheEntry = WATERMARK_CACHE.get(`${imageId}:full`);
            if (cacheEntry && cacheEntry.status === 'ready' && cacheEntry.dataUrl) {
              if (el.src !== cacheEntry.dataUrl) el.src = cacheEntry.dataUrl;
            } else {
              getWatermarkedDataUrl(imageId, 'full').then(dataUrl => {
                if (dataUrl && el) {
                  try { el.src = dataUrl; } catch (e) {}
                }
              }).catch(() => {});
            }
          }
        } catch (e) { /* ignore cross-origin read errors in some browsers */ }
      });
    }

    // Run on DOMContentLoaded so image elements exist
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        const qImage = getQueryParam('image');
        if (qImage) applyWatermarkToImageElements(qImage);
      });
    } else {
      const qImage = getQueryParam('image');
      if (qImage) applyWatermarkToImageElements(qImage);
    }
  })();

})(); // end closure
