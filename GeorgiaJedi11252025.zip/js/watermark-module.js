/**
 * watermark-module.js
 * Standalone version of the watermark engine extracted verbatim from script.js.
 * No table logic, no Bootstrap Table references — safe for imageview.html.
 */

(() => {

    const FONT_NAME = "SFDistantGalaxy";
    const FONT_REL_PATH = "css/fonts/SF Distant Galaxy AltOutline.ttf";
    const FONT_URL = encodeURI(FONT_REL_PATH);
  
    let FONT_LOAD_PROMISE = null;
  
    // Cache structure: key = `${imageId}:${mode}`, value = { status, promise, dataUrl }
    const WATERMARK_CACHE = new Map();
    window._WATERMARK_CACHE = WATERMARK_CACHE; // debug
  
    function scheduleWork(fn) {
      if (typeof requestIdleCallback === "function") {
        requestIdleCallback(fn, { timeout: 500 });
      } else {
        setTimeout(fn, 16);
      }
    }
  
    function isSameOrigin(url) {
      try {
        const u = new URL(url, window.location.href);
        return u.origin === window.location.origin;
      } catch (_) {
        return false;
      }
    }
  
    function ensureFontLoaded() {
      if (FONT_LOAD_PROMISE) return FONT_LOAD_PROMISE;
  
      if (window.FontFace) {
        try {
          const ff = new FontFace(FONT_NAME, `url("${FONT_URL}")`);
          FONT_LOAD_PROMISE = ff.load().then(face => {
            try { document.fonts.add(face); } catch (_) {}
            return document.fonts.load(`12px "${FONT_NAME}"`).then(() => true).catch(() => true);
          }).catch(err => {
            console.warn("FontFace load failed:", FONT_URL, err);
            return true;
          });
        } catch {
          FONT_LOAD_PROMISE = Promise.resolve(true);
        }
      } else if (document.fonts && document.fonts.load) {
        FONT_LOAD_PROMISE = document.fonts.load(`12px "${FONT_NAME}"`)
          .then(() => true)
          .catch(() => true);
      } else {
        FONT_LOAD_PROMISE = Promise.resolve(true);
      }
  
      return FONT_LOAD_PROMISE;
    }
  
    function renderWatermarkedDataUrl(imageUrl, watermarkText = "GeorgiaJedi", sizeHints = null, rotation = -0.6, alpha = 0.55, fontSize = null) {
      return new Promise((resolve, reject) => {
        try {
          const img = new Image();
          if (!isSameOrigin(imageUrl)) img.crossOrigin = "anonymous";
  
          img.onload = function () {
            ensureFontLoaded().then(() => {
              scheduleWork(() => {
                try {
                  const naturalW = img.naturalWidth || img.width || (sizeHints && sizeHints.width) || 1200;
                  const naturalH = img.naturalHeight || img.height || (sizeHints && sizeHints.height) || Math.round(naturalW * 0.75);
  
                  let w = naturalW;
                  let h = naturalH;
  
                  if (sizeHints && sizeHints.width) w = sizeHints.width;
                  if (sizeHints && sizeHints.height) h = sizeHints.height;
  
                  const MAX_DIM = 1600;
                  if (w > MAX_DIM) {
                    const ratio = MAX_DIM / w;
                    w = Math.round(w * ratio);
                    h = Math.round(h * ratio);
                  }
  
                  const canvas = document.createElement("canvas");
                  canvas.width = w;
                  canvas.height = h;
                  const ctx = canvas.getContext("2d");
  
                  ctx.drawImage(img, 0, 0, w, h);
  
                  ctx.save();
                  ctx.translate(w / 2, h / 2);
                  ctx.rotate(rotation);
                  ctx.globalAlpha = alpha;
  
                  const finalFontPx = fontSize ? fontSize : Math.max(18, Math.round(w / 12));
                  ctx.font = `${finalFontPx}px "${FONT_NAME}", Arial`;
                  ctx.fillStyle = "#ffffff";
                  ctx.textAlign = "center";
                  ctx.textBaseline = "middle";
                  ctx.shadowColor = "rgba(0,0,0,0.6)";
                  ctx.shadowBlur = 4;
                  ctx.shadowOffsetX = 1;
                  ctx.shadowOffsetY = 1;
  
                  const step = Math.max(finalFontPx * 4, 80);
                  const span = Math.max(w, h) * 2;
  
                  for (let x = -span; x <= span; x += step) {
                    for (let y = -span; y <= span; y += step * 1.5) {
                      const dx = x + ((y / step) % 2 ? step / 2 : 0);
                      ctx.fillText(watermarkText, dx, y);
                    }
                  }
  
                  ctx.restore();
  
                  const url = canvas.toDataURL("image/jpeg", 0.85);
                  resolve(url);
  
                } catch (err) {
                  reject(err);
                }
              });
            }).catch(() => {
              // Fallback: draw with system font
              scheduleWork(() => {
                try {
                  const naturalW = img.naturalWidth || img.width || (sizeHints && sizeHints.width) || 1200;
                  const naturalH = img.naturalHeight || img.height || (sizeHints && sizeHints.height) || Math.round(naturalW * 0.75);
  
                  let w = naturalW;
                  let h = naturalH;
  
                  if (sizeHints && sizeHints.width) w = sizeHints.width;
                  if (sizeHints && sizeHints.height) h = sizeHints.height;
  
                  const MAX_DIM = 1600;
                  if (w > MAX_DIM) {
                    const ratio = MAX_DIM / w;
                    w = Math.round(w * ratio);
                    h = Math.round(h * ratio);
                  }
  
                  const canvas = document.createElement("canvas");
                  canvas.width = w;
                  canvas.height = h;
                  const ctx = canvas.getContext("2d");
  
                  ctx.drawImage(img, 0, 0, w, h);
  
                  ctx.save();
                  ctx.translate(w / 2, h / 2);
                  ctx.rotate(rotation);
                  ctx.globalAlpha = alpha;
  
                  const finalFontPx = fontSize ? fontSize : Math.max(18, Math.round(w / 12));
                  ctx.font = `${finalFontPx}px Arial`;
                  ctx.fillStyle = "#ffffff";
                  ctx.textAlign = "center";
                  ctx.textBaseline = "middle";
                  ctx.shadowColor = "rgba(0,0,0,0.6)";
                  ctx.shadowBlur = 4;
                  ctx.shadowOffsetX = 1;
                  ctx.shadowOffsetY = 1;
  
                  const step = Math.max(finalFontPx * 4, 80);
                  const span = Math.max(w, h) * 2;
  
                  for (let x = -span; x <= span; x += step) {
                    for (let y = -span; y <= span; y += step * 1.5) {
                      const dx = x + ((y / step) % 2 ? step / 2 : 0);
                      ctx.fillText(watermarkText, dx, y);
                    }
                  }
  
                  ctx.restore();
  
                  const url = canvas.toDataURL("image/jpeg", 0.85);
                  resolve(url);
  
                } catch (err) {
                  reject(err);
                }
              });
            });
          };
  
          img.onerror = () => reject(new Error("Image failed to load: " + imageUrl));
          img.src = imageUrl;
  
        } catch (err) {
          reject(err);
        }
      });
    }
  
    function getWatermarkedDataUrl(imageId, mode = "full") {
      if (!imageId) return Promise.resolve(null);
  
      const key = `${imageId}:${mode}`;
      const cached = WATERMARK_CACHE.get(key);
  
      if (cached) {
        if (cached.status === "ready") return Promise.resolve(cached.dataUrl);
        return cached.promise;
      }
  
      const src = (mode === "thumb")
        ? `images/thumbs/${imageId}_thumb.jpg`
        : `images/${imageId}.jpg`;
  
      const hints = (mode === "thumb") ? { width: 128, height: 128 } : null;
      const fontSize = (mode === "thumb") ? 14 : null;
  
      let resolveFn, rejectFn;
      const promise = new Promise((res, rej) => { resolveFn = res; rejectFn = rej; });
  
      WATERMARK_CACHE.set(key, { status: "pending", promise, dataUrl: null });
  
      scheduleWork(() => {
        renderWatermarkedDataUrl(src, "GeorgiaJedi", hints, -0.6, 0.55, fontSize)
          .then(url => {
            if (url) {
              WATERMARK_CACHE.set(key, { status: "ready", promise: Promise.resolve(url), dataUrl: url });
              resolveFn(url);
            } else {
              WATERMARK_CACHE.set(key, { status: "error", promise: Promise.resolve(null), dataUrl: null });
              resolveFn(null);
            }
          })
          .catch(err => {
            console.warn("Watermark render failed:", src, err);
            WATERMARK_CACHE.set(key, { status: "error", promise: Promise.resolve(null), dataUrl: null });
            resolveFn(null);
          });
      });
  
      return promise;
    }
  
    // Expose public API
    window.getWatermarkedDataUrl = getWatermarkedDataUrl;
    window.ensureWatermarkFont = ensureFontLoaded;
  
  })();
  